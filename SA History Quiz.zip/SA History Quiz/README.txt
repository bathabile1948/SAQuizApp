SA History Quiz  
Version 1.0 

===============================================

DESCRIPTION

SA History Quiz is an app to test your knowledge
about people and events of South Africa.This quiz
covers aspects of political, social, intellectual
and other history dimensions that happened since 
democracy.

Features:
*Multiple Choice Questions
*Score statistics
*Simple User Interface
*Mind-boggling question sets

***Enjoy this Free Knowledge Base!***
Please leave a review for us if you like the app

===============================================

Copyright � 2016 BathabileM. All rights reserved.