package com.example.bmathabatha.sahistoryquiz;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.view.Menu;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class QuizActivity extends Activity {

    TextView tv;
    Button btnNext;
    RadioGroup rg;
    RadioButton rb1, rb2, rb3, rb4;

    String questions[]={"When was the South African flag adopted?","How many ethnical groups form up the Nguni tribe?","Which non racial political party won the first democratic elections?","Who was the first black president of South Africa?","Voortrekker was renamed to?","Who became the first South African in space in April 2002?","Who became the first South African to win an Oscar as best actress?","Which movie directed by Gavin Hood won an Oscar as best foreign language film in 2006?","Who composed the national anthem?","The roll-out of the new smart identity cards started to replace the green ID book in which year?","Which South African player was recognised as World player of the year in 2005 by ICC?","When was the FIFA world cup hosted in South Africa?","Who scored the first goal of the 2010 world cup?","How many colours does the national flag have?","South Africa is the only country in the world to voluntarily abandon which programme?","South Africa is the World's biggest producer of which nut?","Which UNESCO World Heritage can be found near Parys?","What is the size of South Africa in square metres?","Who is credited with coining the phrase-rainbow nation?","Which date did Nelson Mandela marry Graca Machel?"};
    String ans[]={"1994","4","ANC","Nelson Mandela","Thaba Tshwane","Mark Shuttleworth","Charlize Theron","Tsotsi","Enoch Sontonga","2013","Jacques Kallis","2010","Simphiwe Tshabalala","6","Nuclear weapons","Macadamia","Vredefort Dome","1,219,090","Desmond Tutu","18 July 1998"};
    String options[]={"1992","1994","2000","1996","11","9","4","2","PAC","ANC","IFP","EFF","Nelson Mandela","Julius Malema","Jacob Zuma","Thabo Mbeki","Thaba Nchu","Monument Park","Thaba Tshwane","Drakesburg","Chad le Clos","Mark Shuttleworth","Mahatma Ghandi","Roland Schoeman","Leleti Khumalo","Lilian Dube","Charlize Theron","Kuli Roberts","Sarafina","Hansie","White Wedding","Tsotsi","Enoch Sontonga","Johnny Clegg","Mbongeni Ngema","Hugh Masekela","2011","2013","2014","2012","Makhaya Ntini","AB de Villiers","Jacques Kallis","Hansie Cronje","2009","2010","2011","2015","Simphiwe Tshabalala","Reneilwe Letsholonyane","Andile Jali","Bernard Parker","5","7","6","8","Apartheid","Racism","Human Trafficking","Nuclear weapons","Macadamia","Pine","Cashew","Pecan","Mrs Ples","bee","Vredefort Dome","dee","1,219,091","1,219,090","1,219,092","1,219,093","Nelson Mandela","Chris Hani","Walter Sisulu","Desmond Tutu","18 July 1997","18 July 1998","18 July 2000","18 July 1999"};

    int flag=0;
    public static int score,correct,wrong,solution;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        tv=(TextView)findViewById(R.id.tvque);
        btnNext=(Button)findViewById(R.id.btnNext);
        rg=(RadioGroup)findViewById(R.id.radioGroup1);
        rb1=(RadioButton)findViewById(R.id.radio1);
        rb2=(RadioButton)findViewById(R.id.radio2);
        rb3=(RadioButton)findViewById(R.id.radio3);
        rb4=(RadioButton)findViewById(R.id.radio4);

        tv.setText(questions[flag]);
        rb1.setText(options[0]);
        rb2.setText(options[1]);
        rb3.setText(options[2]);
        rb4.setText(options[3]);

        btnNext.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        RadioButton answer=(RadioButton)rg.findViewById(rg.getCheckedRadioButtonId());
        String ansText=answer.getText().toString();
        if(ansText.equalsIgnoreCase(ans[flag]))
        {
            correct++;

        }
        else
        {
            wrong++;
        }
        flag++;


        if (flag<questions.length)
        {
            tv.setText(questions[flag]);
            rb1.setText(options[flag*4]);
            rb2.setText(options[(flag*4)+1]);
            rb3.setText(options[(flag*4)+2]);
            rb4.setText(options[(flag*4)+3]);
        }
        else {
            if (SecondActivity.tbflag) {
                score = correct - wrong;
            } else {
                score = correct;
            }
            Intent in = new Intent(QuizActivity.this, ResultActivity.class);
            startActivity(in);
            QuizActivity.this.finish();
        }
    }
});
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_quiz, menu);
        return true;
    }

}