package com.example.bmathabatha.sahistoryquiz;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ToggleButton;

/**
 * Created by bmathabatha on 2016/04/12.
 */
public class SecondActivity extends Activity{
    Button btn;
    ToggleButton tb;

    public static boolean tbflag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        btn=(Button)findViewById(R.id.btnStartQuiz);
        tb=(ToggleButton)findViewById(R.id.toggleButtonOnOff);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tbflag = tb.isChecked();
                Intent in = new Intent(SecondActivity.this,QuizActivity. class);
                startActivity(in);
                SecondActivity.this.finish();
            }
});
    }
}