package com.example.bmathabatha.sahistoryquiz;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by bmathabatha on 2016/04/11.
 */
public class ResultActivity extends Activity {
    TextView tv;
    Button btnRestart;

    @Override
    protected void onCreate(Bundle savedInstanceState){
super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        tv=(TextView)findViewById(R.id.tvres);
        btnRestart=(Button)findViewById(R.id.btnRestart);

        StringBuffer sb=new StringBuffer();
        sb.append("Correct Answers:"+ QuizActivity.correct);
        sb.append("                                        ");
        sb.append("Wrong Answers:" + QuizActivity.wrong);
        sb.append("                                          ");
        sb.append("Final Score:" + QuizActivity.score);
        tv.setText(sb);
        QuizActivity.correct=0;
        QuizActivity.wrong=0;

        btnRestart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(ResultActivity.this, QuizActivity.class);
                startActivity(in);
                ResultActivity.this.finish();
            }
            {

            }

        });

}

}